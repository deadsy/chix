set path of python and openssl in setpath.bat
launch gen_testref.bat