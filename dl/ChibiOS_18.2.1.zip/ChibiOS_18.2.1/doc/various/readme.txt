chibios_c.xml           - ChibiOS C formatting rules for Eclipse. Import
                           thestyle in Eclipse if you plan to use the ChibiOS
                          formatting rules.
chibios_java.xml        - ChibiOS Java formatting rules for Eclipse. Import
                          the style in Eclipse if you plan to use the ChibiOS
                          formatting rules.
st_usb_cdc_driver.inf   - USB driver for ST Virtual Com Port, several USB
                          demos require this.

