All the code contained under ./os/common/ports are RTOS ports compatible
with both RT and NIL. The code is placed under ./os/common in order to
prevent code duplication and disalignments.
