ChibiOS-Contrib
===============
Code under this directory is not part of the core ChibiOS project 
and the copyright is retained by the original authors. See copyright
notes in file headers.

Code is maintained via Github https://github.com/ChibiOS/ChibiOS-Contrib
Feel free to send pull request there.

#### Using

```bash
# git clone git@github.com:Chibios/ChibiOS.git ChibiOS-RT
# git clone git@github.com:ChibiOS/ChibiOS-Contrib.git ChibiOS-Contrib
```
Note: this repos cloned in the same directory side by side (not inside).

#### Useful links

https://help.github.com/

http://git-scm.com/

http://chibios.org/dokuwiki/doku.php?id=chibios:guides:style_guide
