*****************************************************************************
** ChibiOS/RT port for ARM-Cortex-M0.                                      **
*****************************************************************************

** TARGET **

The demo targets a generic ARM Cortex-M4 device without HAL support.

** The Demo **

** Build Procedure **

** Notes **

The files ch.ld and cmparams.h must be customized for your device. You also
need to provide the CMSIS compliant device header from your vendor, it this
demo an ST header is used.
